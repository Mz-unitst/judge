/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: pass3.h,v 1.3 2012-06-05 09:58:53 dick Exp $
*/

/*	Print the contents of runs */
extern void Show_Runs(void);
