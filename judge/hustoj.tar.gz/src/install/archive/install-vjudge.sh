#!/bin/bash
wget https://github.com/zhblue/vjudge/raw/master/install.sh
sudo bash install.sh
